PULSE 자동 뉴스 홈페이지 — 무료 운영용

중요: 기존 Netlify에 ZIP만 올리면 2시간마다 뉴스가 자동 갱신되지 않습니다.
GitHub와 Netlify의 자동 배포를 최초 1회 연결해야 합니다.

1. GitHub (https://github.com/new)에서 무료 저장소를 만듭니다. 공개(Public) 저장소 권장.
2. 이 ZIP의 폴더 구조 그대로(index.html, scripts, .github, news.json) GitHub 저장소에 업로드합니다.
   주의: .github 숨김 폴더도 반드시 포함해야 합니다.
3. GitHub 저장소 > Actions > Refresh PULSE articles > Run workflow를 한 번 실행합니다.
   이후 2시간마다 GitHub Actions가 뉴스 RSS를 불러와 news.json을 자동 변경합니다.
4. Netlify > Add new project > Import an existing project > GitHub 저장소 선택.
   Build command는 비워두고 Publish directory는 . (점)으로 설정해 Deploy합니다.
   (기존 수동 업로드 사이트에 Git 연결 방법이 보이지 않으면 새 Netlify 사이트를 만들어야 할 수 있습니다.)
5. Site configuration에서 사이트 이름을 woongpa 등 가능한 이름으로 바꿉니다.

비용: GitHub 공개 저장소와 Netlify 무료 플랜의 사용량 제한 내에서 무료.
보장: 무료 서비스의 사용량 제한, 작업 예약 지연, RSS 제공자의 정책에 따라 수집/배포가 지연되거나 실패할 수 있습니다.
이 패키지는 뉴스 기사 제목·출처·게시시간·원문 링크를 보여주며 전체 기사 본문을 복제하지 않습니다.
기사 제목 표현의 긍정·부정 분류는 단순 키워드 기반이며 AI 투자 조언이 아닙니다.
종목 순위는 기사 제목 내 언급 횟수 기준으로 실제 인기나 매매량 순위가 아닙니다.

이메일 구독은 아직 작동하지 않습니다. 실제 이메일 자동 발송에는 발신 이메일 서비스와 사용자 동의/구독취소 기능 연결이 필요합니다.
Google Forms 등 외부 신청 폼 연결 시 개인정보 처리방침과 수신 거부 절차를 준비하세요.
